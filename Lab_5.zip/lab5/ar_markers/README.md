python-ar-markers
=================

Originally developed by Max Brauer <max@max-brauer.de> and Pierre Rouanet <pierre.rouanet@gmail.com>, github https://github.com/DebVortex/python-ar-markers

Jing Dong made several changes, include fix marker generation bug, better visualization, and output marker transformations, github https://github.com/dongjing3309/python-ar-markers
